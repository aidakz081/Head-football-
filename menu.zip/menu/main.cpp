#include <fstream>
#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL2_gfx.h>
#include <string>
#include <SDL2/SDL_mixer.h>
#include <ctime>


using namespace std;

void input(SDL_Renderer *m_renderer,int x,int y,string text);
void window_color(SDL_Renderer *Renderer, int R, int G, int B);
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian );
void ellipse(SDL_Renderer *Renderer, int x, int y, int Radius1, int Radius2, int R, int G, int B, int fill_boolian);
void my_line(SDL_Renderer *Renderer, int x_1, int y_1, int L,double theta,int widht, int R, int G, int B );
void texture(SDL_Renderer *m_renderer,int xp,int yp,string addressOfImage,int width,int height);


int main( int argc, char * argv[] )
{
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048);
    Mix_Music *background1 = Mix_LoadMUS("khoshgel.mp3");
    Mix_Music *background2 = Mix_LoadMUS("Gang.mp3");
    Mix_Music *playing = Mix_LoadMUS("crowd.mp3");
    Mix_Music *goal = Mix_LoadMUS("crowdcheer.mp3");

    int W = 800;
    int L = 1280;
    // be ina kari nadashte bashid
    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN;//| SDL_WINDOW_FULLSCREEN_DESKTOP;//SDL_WINDOW_BORDERLESS ;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init( SDL_flags );
    IMG_Init(IMG_INIT_PNG);
    SDL_CreateWindowAndRenderer( L, W, WND_flags, &m_window, &m_renderer );
    //Pass the focus to the drawing window
    SDL_RaiseWindow(m_window);
    //Get screen res olution
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    // be ina kari nadashte bashid

    string str;
    int x_p2=980,y_p2=530,x_p1=200,y_p1=530,x_s1=210,y_s1=610,x_s2=1020,y_s2=610;
    int x_g2=980,y_g2=400,x_g1=100,y_g1=400;
    int x_t=500,y_t=200,R_t=15;
    int x_b1=600,y_b1=610,r_b1=40;
    int x_setting=1130,y_setting=70,w_setting=80,h_setting=80;
    int x_sound=680,y_sound=300,w_sound=70,h_sound=35,x_music=680,y_music=400,w_music=70,h_music=35;
    int x_back=200,y_back=100,w_back=110,h_back=110;
    double y_b2=250;
    int w_p1=100,h_p1=100,w_p2=100,h_p2=100;
    double dx_b1=50,dx_b2=50;
    int step1=4,step=15,step2=5,x=500,y=500,z;
    int w_bar=0,i,j,b,color,c,d,temp,deltax;
    int  x_play=570,y_play=600,w_play=170,h_play=55;
    int font =5,counter=0;





    SDL_Event *event1 = new SDL_Event();
    SDL_Event *event2 = new SDL_Event();
    SDL_Event*e=new SDL_Event();



    bool boolian=true;
    bool booliann1;
    bool booliann2;
//loading page
    while(boolian=true)
    {
        texture(m_renderer,0,0,"loading.jpg",1280,800);
        rect(m_renderer,0,700,1280,30,120, 120, 120, 1);
        rect(m_renderer,0,700,w_bar,30,255, 255, 255, 1);

// 1 for lazy.ttf , 2 for arial.ttf , 3 for B Roya.ttf
        int x_loading=570;
        int y_loading=660;
        int R=255;
        int G =255;
        int B=255;
        int A=0.5;
        SDL_Color text_color = { 250, 250, 250};
        textColor(m_renderer,x_loading,y_loading,"L o a d i n g . . .",font,24,text_color);
        w_bar+=40;

        SDL_RenderPresent( m_renderer );
        SDL_Delay(10);

        if(w_bar==1280)
        {
            boolian=false;
            break;
        }

    }



    int R=200,G=40,B=40,A=0.5,enter=0;
    SDL_Event ev;
    bool run=true;
    SDL_Color text_color = {250,250,250};
    string page,name1="",name2="", text="";
    SDL_StartTextInput();
    while (run && enter<80)
    {
        texture(m_renderer,0,0,"stadium.jpg",1280,800);


        SDL_PollEvent(&ev);

        if(enter==0)
        {
            if(ev.type==SDL_TEXTINPUT)
                name1+=ev.text.text;
            else if(ev.type==SDL_KEYDOWN&&ev.key.keysym.sym==SDLK_BACKSPACE && name1.length()>0)
                name1.pop_back();
        }

        if(name1.length()!=0 )
            textColor(m_renderer,300,400,name1.c_str(),2,50,text_color);


        if(ev.key.keysym.sym==SDLK_RETURN)
            enter++;

        if(name2.length()!=0 )
            textColor(m_renderer,900,400,name2.c_str(),2,50,text_color);

        if(enter!=0)
        {
            if(ev.type==SDL_TEXTINPUT)
                name2+=ev.text.text;
            else if(ev.type==SDL_KEYDOWN&&ev.key.keysym.sym==SDLK_BACKSPACE && name2.length()>0)
                name2.pop_back();
        }




        ev.type=NULL;

        SDL_RenderPresent( m_renderer );
        SDL_RenderClear(m_renderer);
    }
    SDL_StopTextInput();





    int x_position=620;
    int y_position=610;
//int R=255;
//int G =255;
//int B=255;
//int A=0.5;
//SDL_Color text_color = { 250, 250, 250};

    int ji=1,ij=1;
    string g1 , g2;
    int y_name=100;
string pg1="",pg2="";
// main page including settings and ...
    while(1)
    {
        e->type =NULL;
        SDL_PollEvent(e);
        if( e->type == SDL_MOUSEMOTION )
        {
            x=e->motion.x;
            y=e->motion.y;
        }

        else if(e->type==SDL_MOUSEBUTTONDOWN)
        {
            x=e->button.x;
            y=e->button.y;

            if((x>x_setting)&&(x<x_setting+w_setting)&&(y<y_setting+h_setting)&&(y>y_setting))//press settings icon
                j=1;
            if((x>1120)&&(x<1270)&&(y<100)&&(y>0))//exit
            {
                c=1;
                j=0;
            }
            if((x>310)&&(x<570)&&(y<520)&&(y>420))//music
                ji=-ji;
            if((x>790)&&(x<950)&&(y<550)&&(y>450))//sound
                ij=-ij;


            if ((x>1100)&&(x<1150)&&(y<220)&&(y>180))
                Mix_PlayMusic(background1,-1);

            else if ((x>1100)&&(x<1150)&&(y<290)&&(y>240))
                Mix_PlayMusic(background2,-1);


        }


        if(j==1)

        {
            string music="on.jpg",sound="on.jpg";
            page="settingpage.jpg";
            texture(m_renderer,0,0,page,1280,800);
            texture(m_renderer,310,450,music,250,100);
            texture(m_renderer,790,450,sound,250,100);
            texture(m_renderer,x,y,"handpointer.png",50,50);

            if(ji==-1)
            {
                music="off.jpg";
                Mix_PauseMusic();
                texture(m_renderer,0,0,page,1280,800);
                texture(m_renderer,310,450,music,250,100);
                texture(m_renderer,790,450,sound,250,100);
                texture(m_renderer,x,y,"handpointer.png",50,50);
            }

            if(ji==1)
            {
                music="on.jpg";
                Mix_ResumeMusic();
                texture(m_renderer,0,0,page,1280,800);
                texture(m_renderer,310,450,music,250,100);
                texture(m_renderer,790,450,sound,250,100);
                texture(m_renderer,x,y,"handpointer.png",50,50);
            }

            if(ij==1)
            {
                sound="on.jpg";
                texture(m_renderer,0,0,page,1280,800);
                texture(m_renderer,310,450,music,250,100);
                texture(m_renderer,790,450,sound,250,100);
                texture(m_renderer,x,y,"handpointer.png",50,50);
            }

            if(ij==-1)
            {
                sound="off.jpg";
                texture(m_renderer,0,0,page,1280,800);
                texture(m_renderer,310,450,music,250,100);
                texture(m_renderer,790,450,sound,250,100);
                texture(m_renderer,x,y,"handpointer.png",50,50);
            }

            if(c==1&&j!=1)
            {
                page="stadium.jpg";

                texture(m_renderer,0,0,page,1280,800);
                texture(m_renderer,1100,180,"background1.png",50,50);
                texture(m_renderer,1100,240,"background2.png",50,50);
                rect(m_renderer,x_play,y_play,w_play,h_play,0,255,10, 1 );
                rect(m_renderer,570,600,170,55,20,100,20, 0);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",w_setting,h_setting);
                texture(m_renderer,x,y,"handpointer.png",50,50);
                textColor(m_renderer,x_position,y_position,"P l a y",font,24,text_color);

        ifstream in("Leag.txt");
        in>>name1;
        textColor(m_renderer,100,y_name,name1.c_str(),font,35,text_color);
        in>>g1;
        textColor(m_renderer,300,y_name,g1.c_str(),font,35,text_color);
        in>>name2;
        textColor(m_renderer,100,y_name+50,name2.c_str(),font,35,text_color);
        in>>g2;
        textColor(m_renderer,300,y_name+50,g2.c_str(),font,35,text_color);


            }
        }

        else
        {
            page="stadium.jpg";

            texture(m_renderer,0,0,page,1280,800);
            texture(m_renderer,1100,180,"background1.png",50,50);
            texture(m_renderer,1100,240,"background2.png",50,50);
            rect(m_renderer,x_play,y_play,w_play,h_play,0,255,10, 1 );
            rect(m_renderer,570,600,170,55,20,100,20, 0);
            texture(m_renderer,x_setting,y_setting,"setting.jpg",w_setting,h_setting);
            texture(m_renderer,x,y,"handpointer.png",50,50);
            textColor(m_renderer,x_position,y_position,"P l a y",font,24,text_color);

        ifstream in("Leag.txt");
        in>>name1;
        textColor(m_renderer,100,y_name,name1.c_str(),font,35,text_color);
        in>>g1;
        textColor(m_renderer,300,y_name,g1.c_str(),font,35,text_color);
        in>>name2;
        textColor(m_renderer,100,y_name+50,name2.c_str(),font,35,text_color);
        in>>g2;
        textColor(m_renderer,300,y_name+50,g2.c_str(),font,35,text_color);


        }





        if((x>x_play)&&(x<x_play+w_play)&&(y<y_play+h_play)&&(y>y_play)&&(e->type == SDL_MOUSEBUTTONDOWN))
        {
            rect(m_renderer,x_play-10,y_play-10,w_play+10,h_play+10,0,100,0, 1 );
            textColor(m_renderer,x_position,y_position,"P L A Y",font,24,text_color);
            SDL_RenderPresent( m_renderer );
            SDL_Delay(40);
            boolian=true;
            break;

        }












        SDL_RenderPresent( m_renderer );
        SDL_RenderClear(m_renderer);

    }


    int x_st=590,y_st=400,w_st=170,h_st=270;
    int l=0,r=0,st=0,p=0,u=0;
    string  player1 ;
    string  player2 ;
    string shoe1;
    string shoe2;
    string stadium;

//menu
    while(boolian=true)
    {
        texture(m_renderer,0,0,"stadium.jpg",1280,800);
        texture(m_renderer,325,30,"stadium2.jpg",300,100);
        texture(m_renderer,635,30,"stadium3.jpg",300,100);
        rect(m_renderer,0,270,0,800,50,50,50,1);
        roundedRectangleRGBA(m_renderer,1010,1280,0,800,1,50,50,50,0);
        texture(m_renderer,0,30,"f1.png",120,120);
        texture(m_renderer,0,200,"f2.png",120,120);
        texture(m_renderer,0,370,"f3.png",120,120);
        texture(m_renderer,0,540,"f4.png",120,120);
        texture(m_renderer,170,30,"shoe1.png",100,100);
        texture(m_renderer,170,200,"shoe2.png",100,100);
        texture(m_renderer,170,370,"shoe3.png",100,100);
        texture(m_renderer,170,540,"shoe4.png",100,100);
//rast//
        texture(m_renderer,1140,30,"f1.png",120,120);
        texture(m_renderer,1140,200,"f2.png",120,120);
        texture(m_renderer,1140,370,"f3.png",120,120);
        texture(m_renderer,1140,540,"f4.png",120,120);
        texture(m_renderer,990,30,"shoe1r.png",100,100);
        texture(m_renderer,990,200,"shoe2r.png",100,100);
        texture(m_renderer,990,370,"shoe3r.png",100,100);
        texture(m_renderer,990,540,"shoe4r.png",100,100);
        texture(m_renderer,x_st,y_st,"start.png",w_st,h_st);
        texture(m_renderer,x,y,"handpointer.png",50,50);



        e->type =NULL;
        SDL_PollEvent(e);
        if( e->type == SDL_MOUSEMOTION )
        {
            x=e->motion.x;
            y=e->motion.y;

//bozorg   shodan  e  start
            if(x<x_st+w_st && x>x_st && y>y_st && y<y_st+h_st)
            {
                x_st=565;
                y_st=375;
                w_st=230;
                h_st=320;
                st=1;
            }
            else
            {
                x_st=590;
                y_st=400;
                w_st=170;
                h_st=270;
                st=0;
            }

        }
        else if(e->type==SDL_MOUSEBUTTONDOWN)
        {
            x=e->button.x;
            y=e->button.y;
            // Stadium //
            if((x>300)&&(x<625)&&(y<100)&&(y>30))
                z=1;
            else if((x>635)&&(x<935)&&(y<100)&&(y>30))
                z=2;

            // Left fruit //
            if((x>0)&&(x<120)&&(y<200)&&(y>30))
                l=1;
            else if((x>0)&&(x<120)&&(y<370)&&(y>200))
                l=2;
            else if((x>0)&&(x<120)&&(y<540)&&(y>370))
                l=3;
            else if((x>0)&&(x<120)&&(y<710)&&(y>540))
                l=4;

            //Right fruit//
            if((x>1140)&&(x<1280)&&(y<200)&&(y>30))
                r=1;
            else if((x>1140)&&(x<1280)&&(y<370)&&(y>200))
                r=2;
            else if((x>1140)&&(x<1280)&&(y<540)&&(y>370))
                r=3;
            else if((x>1140)&&(x<1280)&&(y<710)&&(y>540))
                r=4;

            // Left Shoes//
            if((x>170)&&(x<270)&&(y<200)&&(y>30))
                u=1;
            else if((x>170)&&(x<270)&&(y<370)&&(y>200))
                u=2;
            else if((x>170)&&(x<270)&&(y<540)&&(y>370))
                u=3;
            else if((x>170)&&(x<270)&&(y<710)&&(y>540))
                u=4;

            // Right Shoes //
            if((x>990)&&(x<1090)&&(y<200)&&(y>30))
                p=1;
            else if((x>990)&&(x<1090)&&(y<370)&&(y>200))
                p=2;
            else if((x>990)&&(x<1090)&&(y<540)&&(y>370))
                p=3;
            else if((x>990)&&(x<1090)&&(y<710)&&(y>540))
                p=4;


            //start
            else if(st!=0 && l!=0 && r!=0 && p!=0 && u!=0)
            {
                boolian=false;
                break;
            }



        }




        if (l==1)
            texture(m_renderer,300,400,"f1.png",200,200);
        else if (l==2)
            texture(m_renderer,300,400,"f2.png",200,200);
        else if (l==3)
            texture(m_renderer,300,400,"f3.png",200,200);
        else if (l==4)
            texture(m_renderer,300,400,"f4.png",200,200);


        if (r==1)
            texture(m_renderer,780,400,"f1.png",200,200);
        else if (r==2)
            texture(m_renderer,780,400,"f2.png",200,200);
        else if (r==3)
            texture(m_renderer,780,400,"f3.png",200,200);
        else if (r==4)
            texture(m_renderer,780,400,"f4.png",200,200);


        if (p==1)
            texture(m_renderer,830,560,"shoe1r.png",100,100);
        else if (p==2)
            texture(m_renderer,830,560,"shoe2r.png",100,100);
        else if (p==3)
            texture(m_renderer,830,560,"shoe3r.png",100,100);
        else if (p==4)
            texture(m_renderer,830,560,"shoe4r.png",100,100);


        if (u==1)
            texture(m_renderer,350,560,"shoe1.png",100,100);
        else if (u==2)
            texture(m_renderer,350,560,"shoe2.png",100,100);
        else if (u==3)
            texture(m_renderer,350,560,"shoe3.png",100,100);
        else if (u==4)
            texture(m_renderer,350,560,"shoe4.png",100,100);



        if (z==1)
            stadium="stadium2.jpg";
        else if (z==2)
            stadium="stadium3.jpg";


        if (l==1)
            player1="f1.png";
        else if (l==2)
            player1="f2.png";
        else if (l==3)
            player1="f3.png";
        else if (l==4)
            player1="f4.png";

        if (r==1)
            player2="f1.png";
        else if (r==2)
            player2="f2.png";
        else if (r==3)
            player2="f3.png";
        else if (r==4)
            player2="f4.png";

        if (u==1)
            shoe1="shoe1.png";
        else if (u==2)
            shoe1="shoe2.png";
        else if (u==3)
            shoe1="shoe3.png";
        else if (u==4)
            shoe1="shoe4.png";

        if (p==1)
            shoe2="shoe1r.png";
        else if (p==2)
            shoe2="shoe2r.png";
        else if (p==3)
            shoe2="shoe3r.png";
        else if (p==4)
            shoe2="shoe4r.png";



        SDL_RenderPresent( m_renderer );
        SDL_Delay(10);
        SDL_RenderClear(m_renderer);

    }

    bool quit=false;


    double yb;
    int deltay=10;

    string goal1, goal2 ;
    int goall1 =0, goall2=0;
    int w_bar2=0,w_bar1=0;
    x_p2=1280,y_p2=530,x_p1=0,y_p1=530,x_s1=30,y_s1=610,x_s2=1310,y_s2=610;
      Mix_PlayMusic(playing,-1);
    while(y_b2<570 || x_p1<180 || x_p2>1050)//vertical motion of the ball at the beginning of the game
    {
        SDL_Color text_color = { 250, 250, 250};
        y_b2+=deltay;
        x_p1+=20;
        x_s1+=20;
        x_p2-=30;
        x_s2-=30;
        texture(m_renderer,0,0,stadium,1280,800);
        rect(m_renderer,540,90,200,30,28,90,110, 1 );
        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
        texture(m_renderer,576,91,goal1,28,28);
        texture(m_renderer,676,91,goal2,28,28);
        rect(m_renderer,100,90,200,30,120,120,120, 1 );
        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
        rect(m_renderer,100,140,200,30,120,120,120, 1 );
        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
        texture(m_renderer,x_p1,y_p1,player1,100,100);
        texture(m_renderer,x_p2,y_p2,player2,100,100);
        texture(m_renderer,x_b1,y_b2,"balltrans.png",r_b1,r_b1);
        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);



        if (goall2==0)
            goal2="0.png";

        if (goall1==0)
            goal1="0.png";



        int font =5;
        int x_position=585;
        int y_position=50;
//SDL_Color text_color = { 250, 250, 250};
        int R=0;
        int G =0;
        int B=0;
        int A=0.5;

        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);

        deltay+=3;

        SDL_RenderPresent( m_renderer );
        SDL_Delay(25);
        SDL_RenderClear(m_renderer);

    }


    int dx=15,dy=15;
    double zarib=1,ac=3,v=-200,y_b4,y0=570,t;
         int q=0,le=0,jip=1,ijp=1;
    while (boolian=true)// game starts...
    {
        SDL_Color text_color = { 250, 250, 250};




        e->type =NULL;
        SDL_PollEvent(e);
        if( e->type == SDL_MOUSEMOTION )
        {
            x=e->motion.x;
            y=e->motion.y;
        }
        else if(e->type==SDL_MOUSEBUTTONDOWN)
        {
            x=e->button.x;
            y=e->button.y;
            //press P A U S E
            if((x>x_setting)&&(x<x_setting+w_setting)&&(y<y_setting+h_setting)&&(y>y_setting))
                q=1;
            if((x>1100)&&(x<1280)&&(y<100)&&(y>0))//exit
            {
                i=1;
                q=0;
            }
            if((x>400)&&(x<550)&&(y<400)&&(y>300))//music
                jip=-jip;
            if((x>770)&&(x<920)&&(y<400)&&(y>300))//sound
                ijp=-ijp;
            if((x>400)&&(x<800)&&(y<500)&&(y>650))//leave match
                le=1;
        }
        string pagee;
        if (q==1)
        {
            string music="on.jpg",sound="on.jpg";
            pagee="pause.jpeg";
            texture(m_renderer,0,0,pagee,1280,800);
            if(i==1&&q!=1)
            {
                pagee=stadium;
                texture(m_renderer,0,0,pagee,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
            }
            if(jip==-1)
            {
                music="off.jpg";
                texture(m_renderer,0,0,pagee,1280,800);
                texture(m_renderer,410,315,music,150,100);
                texture(m_renderer,780,315,sound,150,100);
                //texture(m_renderer,x,y,"handpointer.jpg",50,50);
            }

            if(jip==1)
            {
                music="on.jpg";
                texture(m_renderer,0,0,pagee,1280,800);
                texture(m_renderer,410,315,music,150,100);
                texture(m_renderer,780,315,sound,150,100);
                //texture(m_renderer,x,y,"handpointer.jpg",50,50);
            }

            if(ijp==1)
            {
                sound="on.jpg";
                Mix_ResumeMusic();
                texture(m_renderer,0,0,pagee,1280,800);
                texture(m_renderer,410,315,music,150,100);
                texture(m_renderer,780,315,sound,150,100);
                //texture(m_renderer,x,y,"handpointer.jpg",50,50);
            }

            if(ijp==-1)
            {
                sound="off.jpg";
                Mix_PauseMusic();
                texture(m_renderer,0,0,pagee,1280,800);
                texture(m_renderer,410,315,music,150,100);
                texture(m_renderer,780,315,sound,150,100);
                //texture(m_renderer,x,y,"handpointer.jpg",50,50);
            }
//            if(le==1);
//            {
//                 SDL_DestroyWindow( m_window );
//                SDL_DestroyRenderer( m_renderer );
//                 SDL_Quit();
//                return 0;
//            }

        }

        else
        {
            pagee=stadium;
            texture(m_renderer,0,0,pagee,1280,800);
            rect(m_renderer,540,90,200,30,28,90,110, 1 );
            my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
            texture(m_renderer,576,91,goal1,28,28);
            texture(m_renderer,676,91,goal2,28,28);
            rect(m_renderer,100,90,200,30,120,120,120, 1 );
            rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
            rect(m_renderer,100,140,200,30,120,120,120, 1 );
            rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
            texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
            texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
            texture(m_renderer,x_p1,y_p1,player1,100,100);
            texture(m_renderer,x_p2,y_p2,player2,100,100);
            texture(m_renderer,x_s1,y_s1,shoe1,50,50);
            texture(m_renderer,x_s2,y_s2,shoe2,50,50);
            texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
            texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

            int font =5;
            int x_position=585;
            int y_position=50;
            int R=0;
            int G =0;
            int B=0;
            int A=0.5;
            SDL_Color text_color = { 250, 250, 250};
            textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
        }

        SDL_RenderPresent( m_renderer );
        SDL_Delay(25);
        SDL_RenderClear(m_renderer);




        if(x_b1>x_g1-10&&x_b1<x_g1+150&&y_b1>y_g1&&y_b1<y_g1+300)//goal ! gate1
        {
            while(w_bar2<200)
            {
                if(w_bar2==0 || w_bar2==100)
                    w_bar2+=100;
                break;
            }

            Mix_PlayMusic(goal,1);
            texture(m_renderer,0,0,stadium,1280,800);
            rect(m_renderer,540,90,200,30,28,90,110, 1 );
            my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
            texture(m_renderer,576,91,goal1,28,28);
            texture(m_renderer,676,91,goal2,28,28);
            rect(m_renderer,100,90,200,30,120,120,120, 1 );
            rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
            rect(m_renderer,100,140,200,30,120,120,120, 1 );
            rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
            texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
            texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
            texture(m_renderer,x_p1,y_p1,player1,100,100);
            texture(m_renderer,540,200,"goal.png",300,250);
            texture(m_renderer,x_p2,y_p2,player2,100,100);
            texture(m_renderer,x_s1,y_s1,shoe1,50,50);
            texture(m_renderer,x_s2,y_s2,shoe2,50,50);
            texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
            textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
            texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);



            goall2++;


            if (goall2==1)
                goal2="1.png";
            else if (goall2==2)
                goal2="2.png";
            else if (goall2==3)
                goal2="3.png";
            else if (goall2==4)
                goal2="4.png";
            else if (goall2==5)
            {
                goal2="5.png";
            }


ofstream out("Leag.txt");
out<<name1<<"\t";
out<<goall1<<endl;
out<<name2<<"\t";
out<<goall2<<endl;

            SDL_Delay(1000);
            SDL_RenderPresent(m_renderer);
            if(goall2==5)
            {
                while(1)
                {
                    texture(m_renderer,0,0,"end.jpg",1280,800);
                    texture(m_renderer,350,200,goal1,200,100);
                    texture(m_renderer,700,200,goal2,200,100);
                    texture(m_renderer,900,200,"winner.png",200,100);

                    SDL_RenderPresent(m_renderer);
                }

            }


            x_b1=640;
            x_p1=200;
            x_s1=210;
            x_p2=980;
            x_s2=1020;
            temp=y_b1;
            temp=200;
            while(temp<570)//vertical motion
            {
                temp+=deltay;
                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                texture(m_renderer,x_b1,temp,"balltrans.png",r_b1,r_b1);
                deltay++;
                SDL_RenderPresent(m_renderer);
                SDL_RenderClear(m_renderer);
            }

        }

        if(x_b1>x_g2&&x_b1<x_g2+200&&y_b1>y_g2&&y_b1<y_g2+300)//goal ! gate2
        {
            while(w_bar1<200)
            {
                if(w_bar1==0 || w_bar1==100)
                    w_bar1+=100;
                break;
            }

            Mix_PlayMusic(goal,1);
            texture(m_renderer,0,0,stadium,1280,800);
            rect(m_renderer,540,90,200,30,28,90,110, 1 );
            my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
            texture(m_renderer,576,91,goal1,28,28);
            texture(m_renderer,676,91,goal2,28,28);
            rect(m_renderer,100,90,200,30,120,120,120, 1 );
            rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
            rect(m_renderer,100,140,200,30,120,120,120, 1 );
            rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
            texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
            texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
            texture(m_renderer,x_p1,y_p1,player1,100,100);
            texture(m_renderer,540,200,"goal.png",300,250);
            texture(m_renderer,x_p2,y_p2,player2,100,100);
            texture(m_renderer,x_s1,y_s1,shoe1,50,50);
            texture(m_renderer,x_s2,y_s2,shoe2,50,50);
            texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
            textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
            texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);




            goall1++;


            if (goall1==1)
                goal1="1.png";
            else if (goall1==2)
                goal1="2.png";
            else if (goall1==3)
                goal1="3.png";
            else if (goall1==4)
                goal1="4.png";
            else if (goall1==5)
                goal1="5.png";



ofstream out("Leag.txt");
out<<name1<<"\t";
out<<goall1<<endl;
out<<name2<<"\t";
out<<goall2<<endl;

            SDL_Delay(1000);
            SDL_RenderPresent(m_renderer);

            if(goall1==5)
            {
                while(1)
                {
                    texture(m_renderer,0,0,"end.jpg",1280,800);
                    texture(m_renderer,350,200,goal1,200,100);
                    texture(m_renderer,700,200,goal2,200,100);
                    texture(m_renderer,150,200,"winner.png",200,100);

                    SDL_RenderPresent(m_renderer);
                }

            }




            x_p1=200;
            x_s1=210;
            x_p2=980;
            x_s2=1020;
            x_b1=640;
            temp=y_b1;
            temp=200;
            while(temp<570)
            {
                temp+=deltay;
                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                texture(m_renderer,x_b1,temp,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                deltay++;
                SDL_RenderPresent(m_renderer);
                SDL_RenderClear(m_renderer);

            }
        }





        if(x_b1<x_p1+80&&x_b1>x_p1)//player1 hits the ball
        {

            for(counter=0; counter<4; counter++)
            {


//                if(x_b1>=x_p2)
//                {
//                    dx_b1=-dx_b1;
//                }
//                x_b1+=dx_b1;



                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                SDL_RenderPresent(m_renderer);



            }

        }



        if(x_b1<x_p2+100&&x_b1>x_p2)//player2 hits the ball
        {

            for(counter=0; counter<4; counter++)
            {


                if(x_b1<=x_p1)
                {
                    dx_b2=-dx_b2;
                }
                x_b1-=dx_b2;



                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                SDL_RenderPresent(m_renderer);




            }
            //dx_b2=-dx_b2;

        }
        int h;

        if(y_b1>y_p1-50&&y_b1<y_p1&&x_b1>x_p1&&x_b1<x_p1+100)//ball hits the player1's head
        {
            y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
            v+=ac*t;


                for(t=0; t<25 && zarib>0.8 ; t+=0.1)
            {
                x_b1+=dx;
                y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                v+=ac*t;

                if(x_b1<200 ||x_b1>1050)
                {
                    dx=-dx;
                    h=1;
                }
                if(y_b4>570 || y_b4<260)
                {
                    zarib*=0.8;
                    t=0;
                    v=-200;
                    y0=570;
                }

                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b4,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                int R=0;
                int G =0;
                int B=0;
                int A=0.5;
                SDL_Color text_color = { 250, 250, 250};
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                SDL_RenderPresent(m_renderer);

            }
            if(h==1)
                dx=-dx;


        }


        if(y_b1>y_p2-50&&y_b1<y_p2&&x_b1>x_p2&&x_b1<x_p2+120)//ball hits the player2's head
        {
            y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
            v+=ac*t;


            for(t=0; t<25 && zarib>0.8 ; t+=0.1)
            {
                x_b1-=dx;
                y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                v+=ac*t;

                if(x_b1<200 ||x_b1>1050)
                {
                    dx=-dx;
                    h=1;
                }
                if(y_b4>570 || y_b4<260)
                {
                    zarib*=0.8;
                    t=0;
                    v=-200;
                    y0=570;
                }

                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,100,100);
                texture(m_renderer,x_p2,y_p2,player2,100,100);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b4,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                int R=0;
                int G =0;
                int B=0;
                int A=0.5;
                SDL_Color text_color = { 250, 250, 250};
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                SDL_RenderPresent(m_renderer);

            }
            if(h==1)
                dx=-dx;

        }


        bool clicked=false;
        bool lock1=0,lock2=0;
        const Uint8 * state=SDL_GetKeyboardState(NULL);



        if( SDL_PollEvent( event1) )
        {

            if( state[SDL_SCANCODE_H] )//code taghalob
            {
                if(player1=="f3.png")
                {
                    w_p1=200;
                    h_p1=200;
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    SDL_Delay(10);
                    SDL_RenderPresent(m_renderer);
                }
                if(player2=="f3.png")
                {
                    h_p2=200;
                    w_p2=200;
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    SDL_Delay(10);
                    SDL_RenderPresent(m_renderer);
                }

            }

            if( state[SDL_SCANCODE_D] && lock1==0)
            {
                if(x_p1+100<x_p2)
                {
                    x_p1+=step;
                    x_s1+=step;
                }
            }

            if( state[SDL_SCANCODE_A] && lock1==0)
            {
                x_p1-=step;
                x_s1-=step;
            }

            if( state[SDL_SCANCODE_W] && lock1==0 )
            {
                y_p1-=60;
                y_s1-=60;
                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                int x_position=585;
                int y_position=50;

                int R=0;
                int G =0;
                int B=0;
                int A=0.5;
                SDL_Color text_color = { 250, 250, 250};
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                SDL_RenderPresent(m_renderer);
                y_p1+=60;
                y_s1+=60;


            }

            if( state[SDL_SCANCODE_S] && lock1==0)//shoot if s was pressed
            {
                x_s1+=50;
                y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                v+=ac*t;

                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

                int x_position=585;
                int y_position=50;
                int R=0,h;
                int G =0;
                int B=0;
                int A=0.5;
                SDL_Color text_color = { 250, 250, 250};
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);

                SDL_RenderPresent(m_renderer);
                x_s1-=50;
                if(x_b1>x_p1&&x_b1<x_p1+130)
                {
                    for(t=0; t<25 && zarib>0.8 ; t+=0.1)
                    {
                        x_b1+=dx;
                        y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                        v+=ac*t;

                        if(x_b1<200 ||x_b1>1050)
                        {
                            dx=-dx;
                            h=1;
                        }
//
//                        if(y_b1>y_p2-35&&y_b1<y_p2&&x_b1>x_p2&&x_b1<x_p2+120)
//                        {
//                            dx=-dx;
//                            h=2;
//                        }


                        if(y_b4>570 || y_b4<260)
                        {
                            zarib*=0.8;
                            t=0;
                            v=-200;
                            y0=570;
                        }

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b4,"balltrans.png",r_b1,r_b1);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                        int R=0;
                        int G =0;
                        int B=0;
                        int A=0.5;
                        SDL_Color text_color = { 250, 250, 250};
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);

                    }
                    if(h==1 || h==2)
                        dx=-dx;
                }


            }


            zarib=1;



            if( state[SDL_SCANCODE_UP] && lock2==0 )
            {
                y_p2-=60;
                y_s2-=60;
                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                int x_position=585;
                int y_position=50;
                SDL_Color text_color = { 250, 250, 250};
                int R=0;
                int G =0;
                int B=0;
                int A=0.5;

                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                SDL_RenderPresent(m_renderer);
                y_p2+=60;
                y_s2+=60;
            }



            if( state[SDL_SCANCODE_LEFT] && lock2==0)
            {
                if(x_p2>x_p1+100)
                {
                    x_p2-=step;
                    x_s2-=step;
                }
            }


            if( state[SDL_SCANCODE_RIGHT]&&lock2==0 )
            {
                x_p2+=step;
                x_s2+=step;
            }

            if( state[SDL_SCANCODE_DOWN] && lock2==0)//shoot if DOWN was pressed
            {
                x_s2-=50;
                y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                v+=ac*t;

                texture(m_renderer,0,0,stadium,1280,800);
                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                texture(m_renderer,576,91,goal1,28,28);
                texture(m_renderer,676,91,goal2,28,28);
                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

                int x_position=585;
                int y_position=50;
                int R=0,h;
                int G =0;
                int B=0;
                int A=0.5;
                SDL_Color text_color = { 250, 250, 250};
                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);

                SDL_RenderPresent(m_renderer);
                x_s2+=50;
                if(x_b1<x_p2&&x_b1>x_p2-50)
                {
                    for(t=0; t<25 && zarib>0.8 ; t+=0.1)
                    {
                        x_b1-=dx;
                        y_b4=(0.5*ac*t*t+v*t)*zarib+y0;
                        v+=ac*t;

                        if(x_b1<200 ||x_b1>1050)
                        {
                            dx=-dx;
                            h=1;
                        }
//
//                        if(y_b1>y_p2-35&&y_b1<y_p2&&x_b1>x_p2&&x_b1<x_p2+120)
//                        {
//                            dx=-dx;
//                            h=2;
//                        }


                        if(y_b4>570 || y_b4<260)
                        {
                            zarib*=0.8;
                            t=0;
                            v=-200;
                            y0=570;
                        }

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b4,"balltrans.png",r_b1,r_b1);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);


                        int R=0;
                        int G =0;
                        int B=0;
                        int A=0.5;
                        SDL_Color text_color = { 250, 250, 250};
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);

                    }
                    if(h==1 || h==2)
                        dx=-dx;
                }


            }



            if( state[SDL_SCANCODE_O] )//Apple's power(invisible ball)player1
            {
                if(player1=="f1.png" &&x_b1>x_p1&&x_b1<x_p1+130 &&w_bar1==200)
                {
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

                    SDL_RenderPresent(m_renderer);
                    SDL_Delay(3000);

                    x_b1+=200;
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                    w_bar1=0;
                }


            }


            if( state[SDL_SCANCODE_O] )//Apple's power(invisible ball)player2
            {
                if(player2=="f1.png" &&x_b1<x_p2&&x_b1>x_p2-50&&w_bar2==200)
                {
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

                    SDL_RenderPresent(m_renderer);
                    SDL_Delay(3000);

                    x_b1-=200;
                    texture(m_renderer,0,0,stadium,1280,800);
                    rect(m_renderer,540,90,200,30,28,90,110, 1 );
                    my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                    texture(m_renderer,576,91,goal1,28,28);
                    texture(m_renderer,676,91,goal2,28,28);
                    rect(m_renderer,100,90,200,30,120,120,120, 1 );
                    rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                    rect(m_renderer,100,140,200,30,120,120,120, 1 );
                    rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                    texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                    texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                    texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                    texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                    texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                    texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                    texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                    textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                    texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);

                    w_bar2=0;
                }

            }



            if( state[SDL_SCANCODE_P] )//Pear's power(Punch)player1
            {

                int x_b3=x_p1+30,y_b3=y_p1+20;
                if(player1=="f2.png" &&x_p2>x_p1&&x_p2<x_p1+350&&w_bar1==200)
                {

                    while(x_b3<x_p2)
                    {
                        x_b3+=40;

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        //SDL_Delay(10);
                        SDL_RenderPresent(m_renderer);
                        SDL_RenderClear(m_renderer);
                    }

                    int start_p1=clock();

                    while( (clock()-start_p1)/1000.0<=3 )
                    {
                        lock2=1;

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        //texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        texture(m_renderer,x_p2,y_p2-70,"why.png",80,80);
                        SDL_Delay(100);
                        SDL_RenderPresent(m_renderer);
                    }
                    lock2=0;
                    w_bar1=0;


                }


            }



            if( state[SDL_SCANCODE_P] )//Pear's power(Punch)player2
            {
                int x_b3=x_p2,y_b3=y_p2+20;
                if(player2=="f2.png" &&x_p2>x_p1&&x_p2<x_p1+350&&w_bar2==200)
                {
                    while(x_b3>x_p1+100)
                    {
                        x_b3-=40;

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        SDL_Delay(10);
                        SDL_RenderPresent(m_renderer);
                        SDL_RenderClear(m_renderer);
                    }

                    int start_p2=clock();

                    while( (clock()-start_p2)/1000.0<=3 )
                    {
                        lock1=1;

                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        //texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        texture(m_renderer,x_p1,y_p1-70,"why.png",80,80);
                        SDL_Delay(100);
                        SDL_RenderPresent(m_renderer);
                    }
                    lock1=0;

                    w_bar2=0;


                }


            }


            if( state[SDL_SCANCODE_ESCAPE] )
            {
                SDL_DestroyWindow( m_window );
                SDL_DestroyRenderer( m_renderer );
                SDL_Quit();
                return 0;

            }



            if( state[SDL_SCANCODE_M] )//Mango's power(kick fire ball)player1
            {
                if(player1=="f4.png" &&x_b1>x_p1&&x_b1<x_p1+130&&w_bar1==200)
                {

                    for(deltax=300; deltax>=70; deltax*=0.5)
                    {

                        // deltax=-deltax+1.3*step1;
                        x_b1+=deltax;
                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        SDL_RenderPresent( m_renderer );
                        x_b1+=dx_b1;
                        if(x_b1>=x_p2)
                        {
                            dx_b1=-dx_b1;
                            for(deltax=100; deltax>=50; deltax*=0.5)
                            {
                                // deltax=-deltax+1.3*step1;
                                x_p2+=deltax;
                                x_s2+=deltax;

                                texture(m_renderer,0,0,stadium,1280,800);
                                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                                texture(m_renderer,576,91,goal1,28,28);
                                texture(m_renderer,676,91,goal2,28,28);
                                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                                texture(m_renderer,x_p2,y_p2-70,"why.png",80,80);

                                SDL_RenderPresent( m_renderer );

                            }

                            int start_k1=clock();

                            while( (clock()-start_k1)/1000.0<=3 )
                            {
                                lock2=1;

                                texture(m_renderer,0,0,stadium,1280,800);
                                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                                texture(m_renderer,576,91,goal1,28,28);
                                texture(m_renderer,676,91,goal2,28,28);
                                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                                //texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                                texture(m_renderer,x_p2,y_p2-70,"why.png",80,80);
                                SDL_Delay(100);
                                SDL_RenderPresent(m_renderer);
                            }
                            lock2=0;


                        }

                        dx_b1=-dx_b1;
                    }
                    w_bar1=0;
                }


            }


            if( state[SDL_SCANCODE_M] )//Mango's power(kick fire ball)player2
            {
                if(player2=="f4.png" && x_b1<x_p2&&x_b1>x_p2-50&&w_bar2==200)
                {

                    for(deltax=300; deltax>=70; deltax*=0.5)
                    {

                        // deltax=-deltax+1.3*step1;
                        x_b1-=deltax;
                        texture(m_renderer,0,0,stadium,1280,800);
                        rect(m_renderer,540,90,200,30,28,90,110, 1 );
                        my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                        texture(m_renderer,576,91,goal1,28,28);
                        texture(m_renderer,676,91,goal2,28,28);
                        rect(m_renderer,100,90,200,30,120,120,120, 1 );
                        rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                        rect(m_renderer,100,140,200,30,120,120,120, 1 );
                        rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                        texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                        texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                        texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                        texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                        texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                        texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                        texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                        textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                        texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                        SDL_RenderPresent( m_renderer );
                        x_b1-=dx_b1;
                        if(x_b1<=x_p1)
                        {
                            dx_b1=-dx_b1;
                            for(deltax=100; deltax>=50; deltax*=0.5)
                            {
                                // deltax=-deltax+1.3*step1;
                                x_p1-=deltax;
                                x_s1-=deltax;
                                texture(m_renderer,0,0,stadium,1280,800);
                                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                                texture(m_renderer,576,91,goal1,28,28);
                                texture(m_renderer,676,91,goal2,28,28);
                                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                                texture(m_renderer,x_p1,y_p1-70,"why.png",80,80);

                                SDL_RenderPresent( m_renderer );

                            }

                            int start_k2=clock();

                            while( (clock()-start_k2)/1000.0<=3 )
                            {
                                lock1=1;

                                texture(m_renderer,0,0,stadium,1280,800);
                                rect(m_renderer,540,90,200,30,28,90,110, 1 );
                                my_line(m_renderer, 640, 119,29,1.57,5, 0, 0, 0 );
                                texture(m_renderer,576,91,goal1,28,28);
                                texture(m_renderer,676,91,goal2,28,28);
                                rect(m_renderer,100,90,200,30,120,120,120, 1 );
                                rect(m_renderer,100,90,w_bar1,30,250,250,250, 1 );
                                rect(m_renderer,100,140,200,30,120,120,120, 1 );
                                rect(m_renderer,100,140,w_bar2,30,250,250,250, 1 );
                                texture(m_renderer,x_g1,y_g1,"gate1.png",200,300);
                                texture(m_renderer,x_g2,y_g2,"gate2.png",200,300);
                                texture(m_renderer,x_p1,y_p1,player1,w_p1,h_p1);
                                texture(m_renderer,x_p2,y_p2,player2,w_p2,h_p2);
                                texture(m_renderer,x_s1,y_s1,shoe1,50,50);
                                texture(m_renderer,x_s2,y_s2,shoe2,50,50);
                                texture(m_renderer,x_b1,y_b1,"balltrans.png",r_b1,r_b1);
                                //texture(m_renderer,x_b3,y_b3,"ball3.png",25,25);
                                textColor(m_renderer,585,50,"S c o r e s",font,24,text_color);
                                texture(m_renderer,x_setting,y_setting,"setting.jpg",80,80);
                                texture(m_renderer,x_p1,y_p1-70,"why.png",80,80);
                                SDL_Delay(100);
                                SDL_RenderPresent(m_renderer);
                            }
                            lock1=0;

                        }

                        dx_b1=-dx_b1;
                    }
                    w_bar2=0;
                }


            }





        }
    }





}




void texture(SDL_Renderer *m_renderer,int xp,int yp,string addressOfImage,int width,int height)
{
    int n = addressOfImage.length();
    char char_array[n+1];

    strcpy(char_array, addressOfImage.c_str());
    SDL_Texture *myTexture;
    myTexture = IMG_LoadTexture( m_renderer, char_array);
    int w1, h1;
    SDL_QueryTexture(myTexture, NULL, NULL, &w1, &h1);
    SDL_Rect texr1;
    texr1.x = xp;
    texr1.y = yp;
    texr1.w = width;
    texr1.h = height;
    SDL_RenderCopy( m_renderer, myTexture, NULL, &texr1);
    SDL_DestroyTexture(myTexture);
}


void my_line(SDL_Renderer *Renderer, int x_1, int y_1, int L, double theta,int widht, int R, int G, int B )

{

    int x_2 = x_1 + L*cos(theta);

    int y_2 = y_1 - L*sin(theta);



    thickLineRGBA(Renderer,x_1,y_1,x_2,y_2,widht,R,G,B,255);


}

void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian )

{

    SDL_Rect rectangle ;

    rectangle.x = x;

    rectangle.y = y;

    rectangle.w = w;

    rectangle.h = h;


    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);

    if (fill_boolian==1)

        SDL_RenderFillRect(Renderer, &rectangle);

    SDL_RenderDrawRect(Renderer, &rectangle);


}

void ellipse(SDL_Renderer *Renderer, int x, int y, int Radius1, int Radius2, int R, int G, int B, int fill_boolian)

{

    if(fill_boolian==1)
        filledEllipseRGBA(Renderer,x,y,Radius1,Radius2,R,G,B,255);

    if(fill_boolian==0)

        ellipseRGBA(Renderer,x,y,Radius1,Radius2,R,G,B,255);


}

void window_color(SDL_Renderer *Renderer, int R, int G, int B)

{

    SDL_SetRenderDrawColor( Renderer, R, G, B, 255 );

    SDL_RenderClear( Renderer );



}
